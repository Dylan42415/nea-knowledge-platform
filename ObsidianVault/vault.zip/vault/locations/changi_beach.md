---
title: Changi beach
type: location
source_file: soe_report.pdf
source_format: pdf
ingested_at: '2026-08-06T15:57:46.887426+00:00'
tags: []
geometry_type: null
coordinates: null
---

A recreational beach monitored for water quality and enterococcus counts.
