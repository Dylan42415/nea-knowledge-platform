---
title: "Hannah \nDavid"
type: concept
source_file: soe_report.pdf
source_format: pdf
ingested_at: '2026-08-06T15:56:27.412906+00:00'
tags: []
---

Extracted via fallback mechanism
